const panels = document.querySelectorAll(".panel");

panels.forEach((panel) => {
    panel.addEventListener("click", () => {
        removeActiveClasses();
        setTimeout(() => {
            panel.classList.add("active");
        }, 300);
    });
});

const removeActiveClasses =() => {
    panels.forEach((panel) => {
        panel.classList.remove("active");
    });
};